export const CART_DISPLAY = "CART_DISPLAY"
export const CartDisplay = (cart) => ({
    type: CART_DISPLAY,
    payload: cart

})