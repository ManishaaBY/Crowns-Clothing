export const REMOVE_ITEM = "REMOVE_ITEM"
export const removeItem = (id) => ({
    type: REMOVE_ITEM,
    payload: id

})